# -*- coding: utf-8 -*-

from . import e_formulaire
from . import e_demande
from . import res_partner
from . import hr_employer
from . import e_stages
from . import res_company
